"""
app.py
Lightweight webhook receiver for TradingView alerts -> Telegram bot sender.
Designed for deployment on Render (or any platform that exposes a public URL).
Security: set BOT_TOKEN and CHAT_ID as environment variables in Render (do NOT hardcode tokens).
"""

import os
import logging
from flask import Flask, request, jsonify
import requests
from datetime import datetime

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

BOT_TOKEN = os.getenv("BOT_TOKEN")
CHAT_ID = os.getenv("CHAT_ID")

if not BOT_TOKEN or not CHAT_ID:
    logging.warning("BOT_TOKEN or CHAT_ID not set. Set them as environment variables before deploying.")

TELEGRAM_API = "https://api.telegram.org/bot{token}/{method}"

app = Flask(__name__)

@app.route("/", methods=["GET"])
def index():
    return "Alchemist SNR Webhook Bot — alive. Use /test to send a test message.", 200

@app.route("/test", methods=["GET"])
def test_send():
    """Send a test message to Telegram (useful to verify BOT_TOKEN and CHAT_ID)"""
    token = BOT_TOKEN or request.args.get("token")
    chat = CHAT_ID or request.args.get("chat_id")
    if not token or not chat:
        return jsonify({"ok": False, "error": "BOT_TOKEN or CHAT_ID missing"}), 400
    text = f"✅ Test message from Alchemist SNR webhook bot at {datetime.utcnow().isoformat()}Z"
    resp = requests.post(TELEGRAM_API.format(token=token, method="sendMessage"),
                         data={"chat_id": chat, "text": text})
    return (resp.text, resp.status_code, {"Content-Type": "application/json"})

@app.route("/webhook", methods=["POST"])
def webhook():
    """
    Endpoint to receive TradingView alerts (JSON).
    Expected JSON fields: you can configure TradingView alert message as JSON with keys:
      - type: "BUY" or "SELL" (optional)
      - symbol: e.g., "XAUUSDm"
      - price: entry price
      - info: any text you want included
    
    The handler will forward a formatted message to your Telegram chat via the bot token.
    """
    data = None
    try:
        data = request.get_json(force=True)
    except Exception as e:
        logging.exception("Failed to parse JSON: %s", e)
        return jsonify({"ok": False, "error": "invalid json"}), 400

    logging.info("Received webhook payload: %s", data)
    # Build message
    alert_type = data.get("type") or data.get("signal") or data.get("side") or "ALERT"
    symbol = data.get("symbol", "XAUUSDm")
    price = data.get("price", "")
    extra = data.get("info", "")
    when = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%SZ")

    text_lines = [
        f"📣 Signal: {alert_type}",
        f"📈 Symbol: {symbol}",
    ]
    if price:
        text_lines.append(f"💲 Price: {price}")
    if extra:
        text_lines.append(f"📝 {extra}")
    text_lines.append(f"⏱️ Time (UTC): {when}")
    text = "\n".join(text_lines)

    token = BOT_TOKEN
    chat = CHAT_ID
    if not token or not chat:
        logging.error("Missing BOT_TOKEN or CHAT_ID environment variables; drop the alert")
        return jsonify({"ok": False, "error": "server misconfiguration"}), 500

    # send to telegram
    try:
        resp = requests.post(TELEGRAM_API.format(token=token, method="sendMessage"),
                             data={"chat_id": chat, "text": text})
        logging.info("Telegram response: %s", resp.text)
        return (resp.text, resp.status_code, {"Content-Type": "application/json"})
    except Exception as e:
        logging.exception("Failed to send message to Telegram: %s", e)
        return jsonify({"ok": False, "error": "failed send"}), 500

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)
