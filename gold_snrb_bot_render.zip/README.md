# Alchemist SNR -> Telegram Webhook Bot (TradingView integration)

This repository contains a minimal Flask app that receives TradingView alerts (via Webhook)
and forwards them to your Telegram bot (chat) using the Bot API.

## How it works (quick)
1. Deploy this app to Render (or any host that gives a public URL).
2. Set environment variables on the host:
   - `BOT_TOKEN` — your Telegram bot token (e.g. `123:ABC...`)
   - `CHAT_ID` — your Chat ID (e.g. `123456789` or `@i444me`)
3. In TradingView, create an alert and set the **Webhook URL** to `https://<your-render-url>/webhook`
   and set the alert message as a JSON payload (example below).
4. When TradingView triggers, this app forwards the alert to Telegram.

## Example TradingView alert message (use "Alert actions" -> "Webhook URL" + "Message")
Set **Message** to a JSON string, for example:
```
{"type":"BUY","symbol":"XAUUSDm","price":"1965.40","info":"M5 pinbar at strong resistance"}
```

## Run locally (for testing)
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
export BOT_TOKEN="your_bot_token_here"
export CHAT_ID="123456789"
python app.py
# Open http://localhost:5000/test to send a test message
```

## Deploy on Render (quick steps)
1. Create a GitHub repo and push these files.
2. Sign in to Render and create a **New Web Service**.
3. Connect the new service to your repo and set the **Start Command** to:
```
gunicorn app:app --bind 0.0.0.0:$PORT --workers 2
```
4. In Render's *Environment* settings, add `BOT_TOKEN` and `CHAT_ID` as environment variables.
5. Deploy. Use the assigned public URL as TradingView's webhook endpoint (`/webhook`).

## Security note
- **Never** publish your `BOT_TOKEN` publicly. If it leaks, revoke it using BotFather and create a new one.
- Keep `CHAT_ID` private as well.
